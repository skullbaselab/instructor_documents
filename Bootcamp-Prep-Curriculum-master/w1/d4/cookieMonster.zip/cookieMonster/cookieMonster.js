var cookieMonster = {

};

/********/
module.exports = cookieMonster; // Don't touch this line
